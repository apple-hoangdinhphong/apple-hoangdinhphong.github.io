if (window.config.language == "Vietnamese") {
var altext = ["Âm lịch ngày"];
var monthtext = ["tháng"];
var yeartext = ["năm"];
var Gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var Zhi = new Array (" Tí", " Sửu", " Dần", " Mão", " Thìn", " Tị", " Ngọ", " Mùi", " Thân", " Dậu", " Tuất", " Hợi");
var days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"];
var condition = ["Có bão", "Bão nhiệt đới", "Có bão", "Có giông", "Giông bão", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
}

if (window.config.language == "English") {
var altext = ["Lunar day"];
var monthtext = ["month"];
var yeartext = [""];
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Rat", " Ox", " Tiger", " Cat", " Dragon", " Snake", " Horse", " Goat", " Monkey", " Rooster", " Dog", " Pig");
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunder", "Thunder", "Rain and snow", "Rain and sleet", "Snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunder", "Scattered thunder", "Scattered thunder", "Scattered showers", "Heavy snow", "Scattered sleet", "Heavy snow", "Partly cloudy", "Thunder", "Snow showers", "Isolated thunder", "Not available"];
}