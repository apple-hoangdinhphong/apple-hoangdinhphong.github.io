function mainUpdate(type){ 
if (type === "weather"){ checkWeather(); }
else 
if (type === "battery"){ updateBattery(); }
}

function checkWeather(){
document.getElementById("Condition").innerHTML = weather.temperature + '&deg;' + ' ' + condition[weather.conditionCode];
}