function updateBattery(){
document.getElementById("Percentage").innerHTML = pertext + ' ' + batteryPercent + '%';
}