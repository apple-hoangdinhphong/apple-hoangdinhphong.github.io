function mainUpdate(type){ 
if(type === "weather"){checkWeather();
} else if (type === "battery"){updateBattery();}
function checkWeather(){
document.getElementById('City').innerHTML = weather.city;
document.getElementById('Condition').innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '&deg;C';
document.getElementById('HiLo').innerHTML = hightext + weather.high + '&deg;' + ' / ' + lowtext + weather.low + '&deg;';}}
checkWeather();
function checkWeather(){setInterval( function() {
window.location.reload();}, 7200000);}

function updateBattery() {
var batt = document.getElementById("Battery");
if(batteryCharging === 1){
batt.innerHTML =  batteryPercent + "% " + charging;
}else{
batt.innerHTML = battext + batteryPercent + "%";}}