if (window.config.language == "Vietnamese") {
var altext = ["Âm lịch"];
var monthtext = ["tháng"];
var yeartext = [""];
var Gan = new Array ("giáp", "ất", "bính", "đinh", "mậu", "kỷ", "canh", "tân", "nhâm", "quý");
var Zhi = new Array (" tí", " sửu", " dần", " mão", " thìn", " tị", " ngọ", " mùi", " thân", " dậu", " tuất", " hợi");
var wetext = ["Thời tiết hiện tại"];
var temptext = ["và nhiệt độ khoảng"];
var days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["có bão", "bão nhiệt đới", "có bão", "có giông", "giông bão", "có tuyết", "mưa đá", "mưa đá", "mưa phùn lạnh", "mưa phùn", "mưa lạnh", "mưa rào", "có mưa", "có bão", "mưa tuyết", "có tuyết", "có tuyết", "mưa đá", "mưa tuyết", "gió bụi", "sương mù dày", "sương mù nhẹ", "sương mù", "gió mạnh", "có gió", "trời lạnh", "có mây vài nơi", "trời nhiều mây", "trời nhiều mây", "có mây vài nơi", "có mây vài nơi", "quang mây", "có nắng", "trời quang mây", "trời nắng", "mưa đá", "trời nóng", "có sấm sét", "có sấm sét", "có sấm sét", "mưa lớn", "có tuyết", "tuyết rơi nhẹ", "tuyết rơi nhiều", "ít mây", "có dông", "có tuyết", "có dông", "blank"];
}

if (window.config.language == "English") {
var altext = ["Lunar"];
var monthtext = ["month"];
var yeartext = ["year"];
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" rat", " ox", " tiger", " cat", " dragon", " snake", " horse", " goat", " monkey", " rooster", " dog", " pig");
var wetext = ["Current"];
var temptext = ["and the temp is around"];
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["tornado", "tropical storm", "hurricane", "thunderstorm", "thunderstorm", "snow", "sleet", "sleet", "freezing drizzle", "drizzle", "freezing rain", "raining", "raining", "flurries", "snow", "snow", "snow", "hail", "sleet", "dust", "fog", "haze", "smoky", "blustery", "windy", "cold", "cloudy", "cloudy", "cloudy", "cloudy", "cloudy", "clear", "sunny", "fair", "fair", "sleet", "hot", "thunderstorms", "thunderstorms", "thunderstorms", "raining", "heavy snow", "light snow", "heavy snow", "partly cloudy", "thunderstorm", "snow", "thunderstorm", "blank"]
}