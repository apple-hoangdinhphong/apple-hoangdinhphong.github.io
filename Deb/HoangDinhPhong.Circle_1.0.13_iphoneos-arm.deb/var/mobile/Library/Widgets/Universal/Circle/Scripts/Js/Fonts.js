let fontFamily = new FontFace("SelectFont", `url('${config.fontSelect}') format("truetype")`);
fontFamily.load().then(function(loadedFont){
document.fonts.add(loadedFont);})