function mainUpdate(type){
if (type === "weather") { checkWeather(); }
else 
if (type === "battery"){ updateBattery(); }
}

function checkWeather(){
document.getElementById("HiLo").innerHTML = hitext + ' ' + weather.high + '&deg' + '. ' + lotext + ' ' + weather.low + '&deg.';
document.getElementById("Forecast").innerHTML = foretext + ' ' + weather.city + ' ' + condition[weather.conditionCode] + ' ' + weather.temperature + '&deg;' + '.';
document.getElementById("WiHu").innerHTML = windtext + ' ' + weather.windSpeed + 'km/h' + ' & ' + humtext + ' ' + weather.humidity + '%' + '.';
document.getElementById("Rain").innerHTML = raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%' + '.';
}