if (window.config.language == "Vietnamese") {
var charging = ["ϟ"];
var notcharging = [""];
var monthtext = ["Tháng"];
var yeartext = [""];
var hitext = ["Cao"];
var lotext = ["Thấp"];
var Gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var Zhi = new Array (" Tí", " Sưu", " Dần", " Mão", " Thìn", " Tị", " Ngọ", " Mùi", " Thân", " Dậu", " Tuất", " Hợi");
var titletext = "♫ Music ♫";
var artisttext = "Không có nghệ sĩ";
var days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["Có bão", "Có bão", "Có bão", "Có giông", "Giông bão", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù", "Sương mù", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây", "Nhiều mây", "Nhiều mây", "Có mây", "Có mây", "Quang mây", "Có nắng", "Quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Sấm sét", "Sấm sét", "Sấm sét", "Mưa lớn", "Có tuyết", "Tuyết ít", "Tuyết nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
}

if (window.config.language == "English") {
var charging = ["ϟ"];
var notcharging = [""];
var monthtext = ["month"];
var yeartext = ["year"];
var hitext = ["Hi"];
var lotext = ["Lo"];
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Rat", " Ox", " Tiger", " Cat", " Dragon", " Snake", " Horse", " Goat", " Monkey", " Rooster", " Dog", " Pig");
var titletext = "♫ Music ♫";
var artisttext = "No Artist";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunder", "Thunder", "Rain and snow", "Rain and sleet", "Snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunder", "Scattered thunder", "Scattered thunder", "Scattered showers", "Heavy snow", "Scattered sleet", "Heavy snow", "Partly cloudy", "Thunder", "Snow showers", "Isolated thunder", "Not available"];
}