function mainUpdate(type){ 
if (type === "battery") { updateBattery();
}
if (type === "weather"){checkWeather();
}
function checkWeather(){
document.getElementById("City").innerHTML = weather.city;
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;C';
document.getElementById('Condition').innerHTML = condition[weather.conditionCode];
document.getElementById('WeInfo').innerHTML = hitext + ' ' + weather.high + "&deg;" + ' ' + raintext +  ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}}