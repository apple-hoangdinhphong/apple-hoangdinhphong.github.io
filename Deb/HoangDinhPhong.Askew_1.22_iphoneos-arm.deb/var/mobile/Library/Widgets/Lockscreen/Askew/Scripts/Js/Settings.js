/*Color*/
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--monthCl', config.monthCl);
document.documentElement.style.setProperty('--weekdayCl', config.weekdayCl);
document.documentElement.style.setProperty('--cityCl', config.cityCl);
document.documentElement.style.setProperty('--conditionCl', config.conditionCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);

document.documentElement.style.setProperty('--ampmCl', config.ampmCl);

document.documentElement.style.setProperty('--todCl', config.todCl);

document.documentElement.style.setProperty('--feelCl', config.feelCl);
document.documentElement.style.setProperty('--batteryCl', config.batteryCl);

/*On Off*/
var doc = document,
bg = doc.getElementById('Bg');
if (config.BlurBackground == true){
Bg.style.visibility = 'visible';
Bg1.style.visibility = 'hidden';
Bg2.style.visibility = 'hidden';
}
if (config.HideBackground == true){
Bg.style.visibility = 'hidden';
Bg1.style.visibility = 'hidden';
Bg2.style.visibility = 'hidden';
}

/*Other*/
document.getElementById('Widget').style.webkitTransform = 'scale(' + config.Scale + ')';
document.getElementById('Bg2').style.backgroundColor = config.BackgroundColor;
document.documentElement.style.setProperty('--dec', config.dec);