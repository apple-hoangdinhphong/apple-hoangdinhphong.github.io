function updateBattery() {
document.getElementById('Percentage').innerHTML = battext + " " + batteryPercent + "%" + (batteryCharging? '<span style="font-size: 12px; position: absolute; left: -22px; top: 7px; left: -25px; color: lime; z-index: 50" class="fas fa-bolt"></span>' : " ");
						
    if(batteryPercent > 0) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Battery/10.png" height="16px">';
    }    
    if(batteryPercent > 20) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/20.png" height="16px">';
    }  
    if(batteryPercent > 30) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/30.png" height="16px">';
    } 
    if(batteryPercent > 40) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/40.png" height="16px">';
    } 
    if(batteryPercent > 50) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/50.png" height="16px">';
    } 
    if(batteryPercent > 60) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/60.png" height="16px">';
    } 

    if(batteryPercent > 70) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/70.png" height="16px">';
    } 

    if(batteryPercent > 80) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/80.png" height="16px">';
    } 

    if(batteryPercent > 90) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/90.png" height="16px">';
    } 

    if(batteryPercent == 100) {
    document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/Battery/100.png" height="16px">';
    } 
}