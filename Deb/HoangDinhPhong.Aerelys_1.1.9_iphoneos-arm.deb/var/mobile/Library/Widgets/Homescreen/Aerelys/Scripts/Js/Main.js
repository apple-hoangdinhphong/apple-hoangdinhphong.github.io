let scrobbleIsDragging = false;
function onload() {
api.media.observeData(function (newData) {
if (newData.isStopped) {} 
handleVolume(newData.volume);
handleTrackTimes(newData.nowPlaying.elapsed, newData.nowPlaying.length, false);
handleScrobblePosition(newData.nowPlaying.elapsed, newData.nowPlaying.length);
});
api.media.observeElapsedTime(function (newElapsedTime) {
handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
handleScrobblePosition(newElapsedTime, api.media.nowPlaying.length);
});
handleVolume(api.media.volume);
}
function handleTrackTimes(elapsed, length, forceUpdate) {
if (scrobbleIsDragging && !forceUpdate) return;
const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
document.getElementById('elapsed').innerHTML = elapsedContent;
const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
document.getElementById('length').innerHTML = lengthContent;
document.getElementById('playback-time').setAttribute('max', length);
document.getElementById('playback-time').value = elapsed;
}
function handleScrobblePosition(elapsed, length) {
if (scrobbleIsDragging) return;
const scrobble = document.getElementById('scrobble-slider');
scrobble.setAttribute('max', length);
scrobble.value = elapsed;
}
function handleVolume(level) {
document.getElementById('volume-slider').setAttribute('value', level);
}
function secondsToFormatted(seconds) {
if (seconds === 0) return '0:00';
const isNegative = seconds < 0;
if (isNegative) return '0:00';
seconds = Math.abs(seconds);
const hours = Math.floor(seconds / 60 / 60);
const minutes = Math.floor(seconds / 60) - (hours * 60);
const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));
if (hours > 0) {
return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
} else {
return minutes + ':' + (secs < 10 ? '0' : '') + secs;}
}
function onVolumeChanged(input) {
api.media.setVolume(input);
}
function onScrobbleUIChanged(input) {
scrobbleIsDragging = true;
handleTrackTimes(input, api.media.nowPlaying.length, true);
}
function onScrobbleChanged(input) {
api.media.seekToPosition(input);
handleTrackTimes(input, api.media.nowPlaying.length, true);
scrobbleIsDragging = false;
}
window.addEventListener("load", function() {}, false);
function init(){
if(da === 1){
updateClock();
if(ti === 0){
setInterval("updateClock();", 120000);}
else{
document.getElementById("day").style.fontFamily = 'TamPhong';
document.getElementById("day").style.fontSize = '20px'
document.getElementById("date").style.fontFamily = 'TruongTamPhong';
document.getElementById("date").style.fontSize = '12px'
document.getElementById("date").style.textTransform = 'uppercase';
setInterval("updateClock();", 1000);}}
checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', br + 'px');
document.documentElement.style.setProperty('--bl', bl + 'px');
document.documentElement.style.setProperty('--primary', C1);
document.documentElement.style.setProperty('--secondary', C2);
document.documentElement.style.setProperty('--aBg', aBg);
if(da === 0){
document.getElementById('dateCont').style.display = 'none';}
document.documentElement.style.setProperty('--dX', dX + 'px');
document.documentElement.style.setProperty('--dY', dY + 'px');
if(se === 0){
document.getElementById('searchCont').style.display = 'none';}
document.documentElement.style.setProperty('--sW', sW + '%');
document.documentElement.style.setProperty('--sX', sX + '%');
document.documentElement.style.setProperty('--sY', sY + 'px');
document.documentElement.style.setProperty('--sBg', sBg);
document.getElementById("in").placeholder = ph;
if(we === 0){
document.getElementById('weaCont').style.display = 'none';}
document.documentElement.style.setProperty('--wW', wW + 'px');
document.documentElement.style.setProperty('--wX', wX + 'px');
document.documentElement.style.setProperty('--wY', wY + 'px');
document.documentElement.style.setProperty('--sBgC', sBgC);
if(mu === 0){
document.getElementById('musCont').style.display = 'none';}
document.documentElement.style.setProperty('--mW', mW + 'px');
document.documentElement.style.setProperty('--primaryB', C3);
document.documentElement.style.setProperty('--mY', mY + 'px');
document.documentElement.style.setProperty('--sBgA', sBgA);
if(ba === 0){
document.getElementById('battCont').style.display = 'none';}
document.documentElement.style.setProperty('--bW', bW + 'px');
document.documentElement.style.setProperty('--bX', bX + 'px');
document.documentElement.style.setProperty('--bY', bY + 'px');
document.documentElement.style.setProperty('--sBgB', sBgB);
if(ac === 0){
document.getElementById('appCont').style.display = 'none';}
document.documentElement.style.setProperty('--aW', aW + '%');
document.documentElement.style.setProperty('--aH', aH + 'px');
document.documentElement.style.setProperty('--aX', aX + '%');
document.documentElement.style.setProperty('--aY', aY + 'px');
if(ac2 === 0){
document.getElementById('appCont2').style.display = 'none';}
document.documentElement.style.setProperty('--abW', abW + '%');
document.documentElement.style.setProperty('--abH', abH + 'px');
document.documentElement.style.setProperty('--abX', abX + '%');
document.documentElement.style.setProperty('--abY', abY + 'px');}
function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutesunit = currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
if(ti === 1){
if(Time24 === 1){Clock = "24h";}
else{Clock = "12h";}
if (Clock === "24h"){currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
if (Clock === "12h"){currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
document.getElementById("day").innerHTML = currentHours + ':' + currentMinutes1 + ' | ';
document.getElementById("date").innerHTML = shortdays[currentTime.getDay()] + ' - ' + currentDate + ' ' + shortmonths[currentTime.getMonth()];}
else{
document.getElementById("day").innerHTML = days[currentTime.getDay()] + " | "
document.getElementById("date").innerHTML = currentDate + " " + shortmonths[currentTime.getMonth()];}}
var input = document.getElementById("in");
input.addEventListener("keyup", function(event) {
if (event.keyCode === 13) {event.preventDefault();
Search();}});
function Search(){
var input = document.getElementById("in").value;
if(input.trim() !== ''){
window.location = 'xeninfo:openurl:google.com.vn/search?q=' + input;
document.getElementById("in").value = "";}}
function openMu(){
if(document.getElementById("musCont").classList.contains('closed')){
document.getElementById("musCont").classList.remove('closed');
document.getElementById("plyBtn").classList.add('open');
document.getElementById("musicArt").classList.remove('open');
document.getElementById("musicArt").classList.add('closed');
return;}
else{
document.getElementById("musCont").classList.add('closed');
document.getElementById("plyBtn").classList.remove('open');
document.getElementById("musicArt").classList.add('open');
document.getElementById("musicArt").classList.remove('closed');
return;}}