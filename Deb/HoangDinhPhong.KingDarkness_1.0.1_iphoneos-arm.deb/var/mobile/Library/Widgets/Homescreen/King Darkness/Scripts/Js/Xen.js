function mainUpdate(type){
if (type === "music"){checkMusic();
} else {
if (type === "weather"){checkWeather();}
}

/*---- WEATHER ----*/
function checkWeather(){
document.getElementById("Hi").innerHTML = weather.high;
document.getElementById("Lo").innerHTML = weather.low;
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
document.getElementById('Temp').innerHTML = weather.temperature;
}}

/*---- MUSIC ----*/
function checkMusic(newData){
document.getElementById('YouTube').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'Scripts/Js/Blank.js';

if (isplaying === 1) {
document.getElementById('Album').style.animation = 'fading 3s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fading 3s linear 1 forwards';
document.getElementById('PlayPause').classList.remove("zeek-buttonplay");		document.getElementById('PlayPause').classList.add("zeek-buttonpause");
document.getElementById('PauseText').style = 'display: none;';
document.getElementById('PlayText').style = 'display: block;';
} else {
document.getElementById('Album').style.animation = '';
document.getElementById('YouTube').style.animation = '';
document.getElementById('PlayPause').classList.remove("zeek-buttonpause");		document.getElementById('PlayPause').classList.add("zeek-buttonplay");
document.getElementById('PauseText').style = 'display: block;';
document.getElementById('PlayText').style = 'display: none;';
}
document.getElementById("PauseText").innerHTML = pause;
document.getElementById("PlayText").innerHTML = play;

if(title === "(null)"){
document.getElementById('Artist').innerHTML = artisttext;
document.getElementById('Title').innerHTML = titletext;
} else {
document.getElementById('Artist').innerHTML = artist;
document.getElementById('Title').innerHTML = title;

if (checkOverflow(document.getElementById('Title')) === true){
document.getElementById('Title').classList.add("corre");
} else {
document.getElementById('Title').classList.remove("corre");}
}
if(album === "(null)"){
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();}}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ){
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi(){
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData);});
}

function HDP(){
XenApi();
}

function openApp(app){
api.apps.launchApplication(app);
}

function playPause() {
if(
document.getElementById('PlayPause').classList.contains("zeek-buttonplay")){ 
document.getElementById('PlayPause').classList.remove("zeek-buttonplay");
document.getElementById('PlayPause').classList.add("zeek-buttonpause");
} else { 
document.getElementById('PlayPause').classList.remove("zeek-buttonpause");
document.getElementById('PlayPause').classList.add("zeek-buttonplay");}

window.location = 'xeninfo:playpause';
document.getElementById('PlayPause').style.opacity = 0;
setTimeout(function (){
document.getElementById('PlayPause').style.opacity = 1;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Album').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('Next').style.opacity = 0;
setTimeout(function (){
document.getElementById('Album').style.animation = '';
document.getElementById('YouTube').style.animation = '';
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Prev').style.opacity = 0.4;
setTimeout(function (){
document.getElementById('Prev').style.opacity = 1;
}, 200);
}

let scrobbleIsDragging = false;
function TP() {
api.media.observeData(function (newData) {
if (newData.isStopped) {} 
handleVolume(newData.volume);
handleTrackTimes(newData.nowPlaying.elapsed, newData.nowPlaying.length, false);
handleScrobblePosition(newData.nowPlaying.elapsed, newData.nowPlaying.length);
});
api.media.observeElapsedTime(function (newElapsedTime) {
handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
handleScrobblePosition(newElapsedTime, api.media.nowPlaying.length);
});
handleVolume(api.media.volume);
}
function handleTrackTimes(elapsed, length, forceUpdate) {
if (scrobbleIsDragging && !forceUpdate) return;
const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
document.getElementById('Elapsed').innerHTML = elapsedContent;
const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
document.getElementById('Length').innerHTML = lengthContent;
document.getElementById('Playback-time').setAttribute('max', length);
document.getElementById('Playback-time').value = elapsed;
}
function handleScrobblePosition(elapsed, length) {
if (scrobbleIsDragging) return;
const scrobble = document.getElementById('Scrobble-slider');
scrobble.setAttribute('max', length);
scrobble.value = elapsed;
}
function handleVolume(level) {
document.getElementById('Volume-slider').setAttribute('value', level);
}
function secondsToFormatted(seconds) {
if (seconds === 0) return '0:00';
const isNegative = seconds < 0;
if (isNegative) return '0:00';
seconds = Math.abs(seconds);
const hours = Math.floor(seconds / 60 / 60);
const minutes = Math.floor(seconds / 60) - (hours * 60);
const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));
if (hours > 0) {
return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
} else {
return minutes + ':' + (secs < 10 ? '0' : '') + secs;}
}
function onScrobbleUIChanged(input) {
scrobbleIsDragging = true;
handleTrackTimes(input, api.media.nowPlaying.length, true);
}
function onScrobbleChanged(input) {
api.media.seekToPosition(input);
handleTrackTimes(input, api.media.nowPlaying.length, true);
scrobbleIsDragging = false;
}
