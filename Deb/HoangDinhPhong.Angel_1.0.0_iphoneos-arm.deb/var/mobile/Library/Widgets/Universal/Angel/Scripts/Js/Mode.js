$('head').removeAttr('Mode');
if (config.Mode == 'Normal') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Normal.css" type="text/css" >');
}
else if (config.Mode == 'Wing') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Wing.css" type="text/css" >');
}