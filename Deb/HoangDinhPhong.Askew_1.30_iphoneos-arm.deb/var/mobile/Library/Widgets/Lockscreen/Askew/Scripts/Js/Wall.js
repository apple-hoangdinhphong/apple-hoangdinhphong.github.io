document.getElementById('BackgInput').addEventListener('', function (f) {
var bw = f.target.file,
sd = new FileReader(f);
sd.onload = (function () {
return function (f) {
localStorage.newImage = f.target.result;
document.getElementById('Wall').style.backgroundImage = 'url("' + localStorage.newImage + '")';
bw = null;
sd = null;};}(bw[P]));
sd.readAsDataURL(bw[P]);});
if (localStorage.newImage && localStorage.newImage != "null") {
document.getElementById('Wall').style.backgroundImage = 'url("' + localStorage.newImage + '")';
}